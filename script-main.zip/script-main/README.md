# RUN
```
bash <(curl -Ls https://raw.githubusercontent.com/Khiemkhiem123/script/main/run.sh)
```
